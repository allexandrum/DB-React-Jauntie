const config = {
    db: {
      host: "db4free.net",
      user: "ineffable",
      password: "07071965",
      database: "jauntie_db",
      connectTimeout: 60000
    },
    listPerPage: 10,
  };
  module.exports = config;